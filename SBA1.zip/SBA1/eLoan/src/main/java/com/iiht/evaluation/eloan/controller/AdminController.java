package com.iiht.evaluation.eloan.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iiht.evaluation.eloan.dao.ConnectionDao;
import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;


@WebServlet("/admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ConnectionDao connDao;
	
	public void setConnDao(ConnectionDao connDao) {
		this.connDao = connDao;
	}
	public void init(ServletConfig config) {
		String jdbcURL = config.getServletContext().getInitParameter("jdbcUrl");
		String jdbcUsername = config.getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = config.getServletContext().getInitParameter("jdbcPassword");
		System.out.println(jdbcURL + jdbcUsername + jdbcPassword);
		this.connDao = new ConnectionDao(jdbcURL, jdbcUsername, jdbcPassword);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action =  request.getParameter("action");
		System.out.println(action);
		String viewName = "";
		try {
			switch (action) {
			case "listall" : 
				viewName = listall(request, response);
				break;
			case "process":
				viewName=process(request,response);
				break;
			case "callemi":
				viewName=calemi(request,response);
				break;
			case "updatestatus":
				viewName=updatestatus(request,response);
				break;
			case "logout":
				viewName = adminLogout(request, response);
				break;	
			case "adminhome":
				viewName = adminhome(request, response);
				break;
			case "getLoanStatus":
				viewName = getLoanStatus(request, response);
				break;
			case "adminEditLoan":
				viewName = adminEditLoan(request, response);
				break;
			case "displayEMI":
				viewName = displayEMI(request, response);
				break;	
			default : viewName = "notfound.jsp"; break;		
			}
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}
		RequestDispatcher dispatch = 
					request.getRequestDispatcher(viewName);
		dispatch.forward(request, response);
		
		
	}

	private String updatestatus(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		/* write the code for updatestatus of loan and return to admin home page */
		int amount, mobile;

		String loanNumber=request.getParameter("loannumber");
		String loanName=request.getParameter("loanname");
		amount=Integer.parseInt(request.getParameter("loanamtrequested"));
		String loanDate=request.getParameter("loandate");
		String bStructure=request.getParameter("businesstructure");
		String bIndicator=request.getParameter("billingindicator");
		String taxIndicator=request.getParameter("taxindicator");
		String address=request.getParameter("address");
		mobile=Integer.parseInt(request.getParameter("mobilenumber"));
		String email=request.getParameter("emailid");
		String status=request.getParameter("status");
		
		LoanInfo updateLoan = new LoanInfo(loanNumber, loanName, amount, loanDate, bStructure, bIndicator, taxIndicator,
				address, email, mobile, status);
		connDao.updateLoan(updateLoan);
		
		return "adminhome1.jsp";
	}
	private String calemi(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
	/* write the code to calculate emi for given applno and display the details */
		int loanNumber=Integer.parseInt(request.getParameter("loanappnumber"));
		List<LoanInfo> loanDetails = connDao.displayLoan(loanNumber);
		
		int amountRequested = loanDetails.get(0).getAmtrequest();
		
		int amountSanctioned;
		int loanTerm = 15;//years
		int loanTermMonths = (loanTerm*12); 
		String paymentStartDate;
		String loanClosureDate;
		int emi;
		
		int termPayment;
		int interestRate = 10;
		
		amountSanctioned = (int) (amountRequested * 0.95); //assuming 95% of requested loan amount is approved
		float interestPercent = 1+(interestRate/100);
		int termPaymentPartB = (int) Math.pow(interestPercent, loanTermMonths);
		termPayment = amountSanctioned * termPaymentPartB;
		emi = termPayment/loanTermMonths; //monthly payment
		System.out.println("EMI: "+emi);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = new Date();
		// Convert Date to Calendar
        Calendar c = Calendar.getInstance();
        c.setTime(startDate);
        c.add(Calendar.YEAR, 15);
        Date closureDate = c.getTime();
        
        paymentStartDate = dateFormat.format(startDate);
        loanClosureDate = dateFormat.format(closureDate);
		
        ApprovedLoan adminUpdate = new ApprovedLoan(Integer.toString(loanNumber),amountSanctioned,loanTerm, paymentStartDate,loanClosureDate, emi);
        connDao.adminLoanUpdate(adminUpdate);
		
		return "calemi.jsp";
	}
	private String process(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
	/* return to process page */
		return  "process.jsp";
	}
	private String adminLogout(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	/* write code to return index page */
		return "index.jsp";
	}

	private String listall(HttpServletRequest request, HttpServletResponse response) throws SQLException {
	/* write the code to display all the loans */
		List<LoanInfo> loanDetails = connDao.displayAllLoans();
	    request.setAttribute("loanDetails", loanDetails);
		return "listall.jsp";
	}

	private String adminhome(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		
		return "adminhome1.jsp";
	}
	
	private String getLoanStatus(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		    
		return "getLoanStatus.jsp";
	}
	
	private String adminEditLoan(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		int loanNumber=Integer.parseInt(request.getParameter("loanappnumber"));
		List<LoanInfo> loanDetails = connDao.displayLoan(loanNumber);
	    request.setAttribute("loanDetails", loanDetails);
		return "admineditloan.jsp";
	}
	
	private String displayEMI(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		int loanNumber=Integer.parseInt(request.getParameter("loanappnumber"));
		List<ApprovedLoan> emiDetails = connDao.dispApprovedLoan(loanNumber);
	    request.setAttribute("emidetails", emiDetails);
		return "calemi.jsp";
	}
}