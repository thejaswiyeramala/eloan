package com.iiht.evaluation.eloan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;

import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.dto.UserDto;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;
import com.iiht.evaluation.eloan.model.User;

public class ConnectionDao {
	private static final long serialVersionUID = 1L;
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;
	private Statement jdbcStatement;
	private ResultSet jdbcResultSet;
	private UserDto userDto;

	public ConnectionDao(String jdbcURL, String jdbcUsername, String jdbcPassword) {
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	public  Connection connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
		
		return jdbcConnection;
	}

	public void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}
	
	public void insertUser(User user) throws SQLException {
		try {
			connect();
			PreparedStatement ps = jdbcConnection.prepareStatement
					("INSERT INTO user (username,password) VALUES (?,?)");
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			System.out.println("Record inserted into USER Table: "+ps);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public String validateUser(String username,String password) throws SQLException {
		String status, dbUsername, dbPassword;
		status = null;
		try {
			connect();
			String sqlValidateQuery = "select * from eloan.user where username=?";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlValidateQuery);

			ps.setString(1,username);
			System.out.println(ps);
			// Step 3: Execute the query or update query
			jdbcResultSet = ps.executeQuery();

			// Step 4: Process the ResultSet object.
			while (jdbcResultSet.next()) {
				dbUsername = jdbcResultSet.getString("username");
				dbPassword = jdbcResultSet.getString("password");
				if ((username.equalsIgnoreCase(dbUsername)) && (password.equals(dbPassword))) {
					status="Found";
				}
				
				else {
					status=null;
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		return status;
	}
	
	public void insertLoan(LoanInfo newLoan) throws SQLException {
		try {
			connect();
			PreparedStatement ps = jdbcConnection.prepareStatement
						("INSERT INTO loans (loanid, loanname, loanamountrequested, loanapplicationdate, businessstructure, billingindicator, taxindicator, contactaddress, emailID, contactnumber, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
			
			ps.setString(1, newLoan.getApplno());
			ps.setString(2, newLoan.getPurpose());
			ps.setInt(3, newLoan.getAmtrequest());
			ps.setString(4, newLoan.getDoa());
			ps.setString(5, newLoan.getBstructure());
			ps.setString(6, newLoan.getBindicator());
			ps.setString(7, newLoan.getTindicator());
			ps.setString(8, newLoan.getAddress());
			ps.setString(9, newLoan.getEmail());
			ps.setInt(10, newLoan.getMobile());
			ps.setString(11, newLoan.getStatus());
			System.out.println("Record inserted into loans Table: "+ps);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<LoanInfo> displayLoan(int loanid) throws SQLException {
		List<LoanInfo> loanDetails = new ArrayList<LoanInfo>();
		try {
			connect();
			String sqlDisplayQuery = "select * from loans where loanid=?;";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlDisplayQuery);
	        ps.setInt(1, loanid); //set loanid like this (The '1' means first occurrence of a question mark '?')
	        jdbcResultSet = ps.executeQuery();
			
			/*jdbcStatement = connect().createStatement();
			jdbcResultSet = jdbcStatement.executeQuery(sqlDisplayQuery);*/
				
			while(jdbcResultSet.next()) {
				LoanInfo existingLoan = new LoanInfo(); 
				existingLoan.setApplno(Integer.toString(jdbcResultSet.getInt("loanid")));
				existingLoan.setPurpose((jdbcResultSet.getString("loanname")));
				existingLoan.setAmtrequest(jdbcResultSet.getInt("loanamountrequested"));
				existingLoan.setDoa(jdbcResultSet.getString("loanapplicationdate"));
				existingLoan.setBstructure(jdbcResultSet.getString("businessstructure"));
				existingLoan.setBindicator(jdbcResultSet.getString("billingindicator"));
				existingLoan.setTindicator(jdbcResultSet.getString("taxindicator"));
				existingLoan.setAddress(jdbcResultSet.getString("contactaddress"));
				existingLoan.setEmail(jdbcResultSet.getString("emailID"));
				existingLoan.setTindicator(jdbcResultSet.getString("taxindicator"));
				existingLoan.setMobile(jdbcResultSet.getInt("contactnumber"));
				existingLoan.setStatus(jdbcResultSet.getString("status"));
				loanDetails.add(existingLoan);
				System.out.println(existingLoan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return loanDetails;
	}
	
	public void updateLoan(LoanInfo updateLoan) throws SQLException {
		try {
			connect();
			String sqlUpdateQuery = "update loans set loanid=?, loanname=?, loanamountrequested=?, loanapplicationdate=?, businessstructure=?, billingindicator=?, taxindicator=?, contactaddress=?, emailID=?, contactnumber=?, status=? where loanid=?";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlUpdateQuery);
			ps.setString(12, updateLoan.getApplno());
			
			ps.setString(1, updateLoan.getApplno());
			ps.setString(2, updateLoan.getPurpose());
			ps.setInt(3, updateLoan.getAmtrequest());
			ps.setString(4, updateLoan.getDoa());
			ps.setString(5, updateLoan.getBstructure());
			ps.setString(6, updateLoan.getBindicator());
			ps.setString(7, updateLoan.getTindicator());
			ps.setString(8, updateLoan.getAddress());
			ps.setString(9, updateLoan.getEmail());
			ps.setInt(10, updateLoan.getMobile());
			ps.setString(11, updateLoan.getStatus());
			
			System.out.println("Record updated into loans Table: "+ps);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<LoanInfo> displayAllLoans() throws SQLException {
		List<LoanInfo> loanDetails = new ArrayList<LoanInfo>();
		try {
			connect();
			String sqlAllLoansQuery = "select * from loans";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlAllLoansQuery);
	       // ps.setInt(1, loanid); //set loanid like this (The '1' means first occurrence of a question mark '?')
	        jdbcResultSet = ps.executeQuery();
			
			/*jdbcStatement = connect().createStatement();
			jdbcResultSet = jdbcStatement.executeQuery(sqlDisplayQuery);*/
				
			while(jdbcResultSet.next()) {
				LoanInfo loan = new LoanInfo(); 
				loan.setApplno(Integer.toString(jdbcResultSet.getInt("loanid")));
				loan.setPurpose((jdbcResultSet.getString("loanname")));
				loan.setAmtrequest(jdbcResultSet.getInt("loanamountrequested"));
				loan.setDoa(jdbcResultSet.getString("loanapplicationdate"));
				loan.setBstructure(jdbcResultSet.getString("businessstructure"));
				loan.setBindicator(jdbcResultSet.getString("billingindicator"));
				loan.setTindicator(jdbcResultSet.getString("taxindicator"));
				loan.setAddress(jdbcResultSet.getString("contactaddress"));
				loan.setEmail(jdbcResultSet.getString("emailID"));
				loan.setTindicator(jdbcResultSet.getString("taxindicator"));
				loan.setMobile(jdbcResultSet.getInt("contactnumber"));
				loan.setStatus(jdbcResultSet.getString("status"));
				loanDetails.add(loan);
				System.out.println(loan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return loanDetails;
	}
	
	public void adminLoanUpdate(ApprovedLoan updateLoan) throws SQLException {
		try {
			connect();
			String sqlUpdateQuery = "update loans set loanid=?, loanamountsanctioned=?, loanterm=?, paymentstartdate=?, loanclosuredate=?, emi=? where loanid=?";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlUpdateQuery);
			ps.setString(7, updateLoan.getApplno());
			
			ps.setString(1, updateLoan.getApplno());
			ps.setInt(2, updateLoan.getAmotsanctioned());
			ps.setInt(3, updateLoan.getLoanterm());
			ps.setString(4, updateLoan.getPsd());
			ps.setString(5, updateLoan.getLcd());
			ps.setInt(6, updateLoan.getEmi());
			
			System.out.println("Record updated into loans Table: "+ps);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public List<ApprovedLoan> dispApprovedLoan(int loanid) throws SQLException {
		List<ApprovedLoan> approvedLoan = new ArrayList<ApprovedLoan>();
		try {
			connect();
			String sqlDisplayQuery = "select * from loans where loanid=?;";
			PreparedStatement ps = jdbcConnection.prepareStatement(sqlDisplayQuery);
	        ps.setInt(1, loanid); //set loanid like this (The '1' means first occurrence of a question mark '?')
	        jdbcResultSet = ps.executeQuery();
			
			/*jdbcStatement = connect().createStatement();
			jdbcResultSet = jdbcStatement.executeQuery(sqlDisplayQuery);*/
				
			while(jdbcResultSet.next()) {
				ApprovedLoan loanemi = new ApprovedLoan(); 
				loanemi.setApplno(Integer.toString(jdbcResultSet.getInt("loanid")));
				loanemi.setAmotsanctioned(jdbcResultSet.getInt("loanamountsanctioned"));
				loanemi.setLoanterm(jdbcResultSet.getInt("loanterm"));
				loanemi.setPsd(jdbcResultSet.getString("paymentstartdate"));
				loanemi.setLcd(jdbcResultSet.getString("loanclosuredate"));
				loanemi.setEmi(jdbcResultSet.getInt("emi"));
				approvedLoan.add(loanemi);
				System.out.println(approvedLoan);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return approvedLoan;
	}
	
	//To be deleted
	public Statement createStatement() {
		try {
			connect();
			jdbcStatement = connect().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
														ResultSet.CONCUR_UPDATABLE);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return jdbcStatement;
	}
	
	//To be deleted
	/*public void fireQuery() {
		
		try {
			//select
			jdbcResultSet = createStatement().executeQuery("select * from kyc");
			
			while (jdbcResultSet.next()) {
				System.out.println(jdbcResultSet.getInt(1)
						+ " | " + jdbcResultSet.getString(2)
						+ " | " + jdbcResultSet.getString(3)
						+ " | " + jdbcResultSet.getInt(4)
						+ " | " + jdbcResultSet.getString(5));
			}
			
			jdbcResultSet.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	// put the relevant DAO methods here..
}
